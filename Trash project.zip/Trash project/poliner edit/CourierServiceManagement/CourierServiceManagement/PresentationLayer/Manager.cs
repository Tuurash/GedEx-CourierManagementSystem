﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourierServiceManagement.DatabaseAccessLayer;

namespace CourierServiceManagement.PresentationLayer
{
    public partial class Manager : MetroFramework.Forms.MetroForm
    {
        private Connection con { get; set; }
        private DataSet Ds { get; set; }
        private Login Log { get; set; }
        private string TempId;
        loginvisible loginVisibility { get; set; }
        public Manager(loginvisible temp)
        {
            InitializeComponent();
            this.loginVisibility = temp;
            this.con = new Connection();
            //this.Log = log;
        }

        public void PopulateGridView(string sql = "select * from ProductDb;")
        {
            this.Ds = this.con.ExecuteQuery(sql);

            this.dgvAll.AutoGenerateColumns = false;
            this.dgvAll.DataSource = this.Ds.Tables[0];
        }
        private void btnAll_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private void btnPending_Click(object sender, EventArgs e)
        {
            this.PopulateGridView("select * from ProductDb where condition = " + "'pending'");
        }

        private void Manager_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Visible = false;
            this.loginVisibility();
        }

        private void btnDelivered_Click(object sender, EventArgs e)
        {
            this.PopulateGridView("select * from ProductDb where condition = " + "'delivered'");
        }

        private void btnNewEmp_Click(object sender, EventArgs e)
        {
            var ne = new NewEmployee(this);
            ne.Visible = true;
            this.Visible = false;
        }

        private void btnSubmitted_Click(object sender, EventArgs e)
        {
            this.PopulateGridView("select * from ProductDb where condition = " + "'submitted'");
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            string sql = "update ProductDb set condition= 'pending' where ProductId=" + this.TempId;
            this.con.ExecuteUpdateQuery(sql);
            this.PopulateGridView("select * from ProductDb where condition = " + "'submitted'");
        }

        private void dgvAll_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string temp;
            temp = this.dgvAll.CurrentRow.Cells["productId"].Value.ToString();
            this.TempId = temp;
        }

        

        private void btnViewEmp_Click(object sender, EventArgs e)
        {
            var empView = new EmployeeGrid(this);
            this.Visible = false;
            empView.Visible = true;
        }

        private void btnViewCustomer_Click(object sender, EventArgs e)
        {
            var custview = new CustomerGrid(this);
            this.Visible = false;
            custview.Visible = true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourierServiceManagement.DatabaseAccessLayer;
using CourierServiceManagement.BusinessLayer;

namespace CourierServiceManagement.PresentationLayer
{
    public partial class Employee : MetroFramework.Forms.MetroForm
    {
        private Connection con { get; set; }
        private DataSet Ds { get; set; }
        private string TempId=null;
        private static int Id { get; set; }
        public Employee(int id)
        {
            InitializeComponent();
            Id = id;
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'courierServiceDBDataSet2.ProductDb' table. You can move, or remove it, as needed.
            this.productDbTableAdapter.Fill(this.courierServiceDBDataSet2.ProductDb);

        }

        private void BtnDelivery_Click(object sender, EventArgs e)
        {
            if (TempId != null)
            {
                string sql = "update ProductDb set condition= 'delivered' where ProductId=" + this.TempId;
                this.con.ExecuteUpdateQuery(sql);
                var emprepo = new EmployeeRepository();
                this.Ds = emprepo.Display();
                this.dgvAll.DataSource = this.Ds.Tables[0];
            }
        }

        

        private void dgvAll_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string temp;
            temp = this.dgvAll.CurrentRow.Cells["productId"].Value.ToString();
            this.TempId = temp;
        }

        private void Employee_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            string sql = "select * from ProductDb where address=(select address from Employee where customerId=" + Id + " )";
            this.Ds = this.con.ExecuteQuery(sql);
            var Customerrep = new CustomerRepository();
            // this.Ds = Customerrep.Display();
            this.dgvAll.DataSource = this.Ds.Tables[0];
        }
    }
}

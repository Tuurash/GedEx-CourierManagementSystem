﻿namespace CourierServiceManagement.PresentationLayer
{
    partial class OrderSubmit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OrderPanel = new MetroFramework.Controls.MetroPanel();
            this.SdateTxt = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.SubmitBtn = new MetroFramework.Controls.MetroButton();
            this.AddressTxt = new MetroFramework.Controls.MetroTextBox();
            this.NameTxt = new MetroFramework.Controls.MetroTextBox();
            this.AddressLbl = new MetroFramework.Controls.MetroLabel();
            this.Date = new MetroFramework.Controls.MetroLabel();
            this.OrderNamelbl = new MetroFramework.Controls.MetroLabel();
            this.OrderPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // OrderPanel
            // 
            this.OrderPanel.Controls.Add(this.SdateTxt);
            this.OrderPanel.Controls.Add(this.metroLabel1);
            this.OrderPanel.Controls.Add(this.SubmitBtn);
            this.OrderPanel.Controls.Add(this.AddressTxt);
            this.OrderPanel.Controls.Add(this.NameTxt);
            this.OrderPanel.Controls.Add(this.AddressLbl);
            this.OrderPanel.Controls.Add(this.Date);
            this.OrderPanel.Controls.Add(this.OrderNamelbl);
            this.OrderPanel.HorizontalScrollbarBarColor = true;
            this.OrderPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.OrderPanel.HorizontalScrollbarSize = 10;
            this.OrderPanel.Location = new System.Drawing.Point(23, 63);
            this.OrderPanel.Name = "OrderPanel";
            this.OrderPanel.Size = new System.Drawing.Size(787, 527);
            this.OrderPanel.TabIndex = 0;
            this.OrderPanel.VerticalScrollbarBarColor = true;
            this.OrderPanel.VerticalScrollbarHighlightOnWheel = false;
            this.OrderPanel.VerticalScrollbarSize = 10;
            // 
            // SdateTxt
            // 
            this.SdateTxt.CustomFormat = "yyyy-MM-dd";
            this.SdateTxt.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SdateTxt.Location = new System.Drawing.Point(199, 127);
            this.SdateTxt.MinimumSize = new System.Drawing.Size(0, 29);
            this.SdateTxt.Name = "SdateTxt";
            this.SdateTxt.Size = new System.Drawing.Size(200, 29);
            this.SdateTxt.TabIndex = 13;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(199, 188);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(0, 0);
            this.metroLabel1.TabIndex = 12;
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(199, 332);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(137, 56);
            this.SubmitBtn.TabIndex = 11;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseSelectable = true;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // AddressTxt
            // 
            // 
            // 
            // 
            this.AddressTxt.CustomButton.Image = null;
            this.AddressTxt.CustomButton.Location = new System.Drawing.Point(85, 1);
            this.AddressTxt.CustomButton.Name = "";
            this.AddressTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AddressTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AddressTxt.CustomButton.TabIndex = 1;
            this.AddressTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AddressTxt.CustomButton.UseSelectable = true;
            this.AddressTxt.CustomButton.Visible = false;
            this.AddressTxt.Lines = new string[0];
            this.AddressTxt.Location = new System.Drawing.Point(199, 188);
            this.AddressTxt.MaxLength = 32767;
            this.AddressTxt.Name = "AddressTxt";
            this.AddressTxt.PasswordChar = '\0';
            this.AddressTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AddressTxt.SelectedText = "";
            this.AddressTxt.SelectionLength = 0;
            this.AddressTxt.SelectionStart = 0;
            this.AddressTxt.ShortcutsEnabled = true;
            this.AddressTxt.Size = new System.Drawing.Size(107, 23);
            this.AddressTxt.TabIndex = 10;
            this.AddressTxt.UseSelectable = true;
            this.AddressTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AddressTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NameTxt
            // 
            // 
            // 
            // 
            this.NameTxt.CustomButton.Image = null;
            this.NameTxt.CustomButton.Location = new System.Drawing.Point(85, 1);
            this.NameTxt.CustomButton.Name = "";
            this.NameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NameTxt.CustomButton.TabIndex = 1;
            this.NameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NameTxt.CustomButton.UseSelectable = true;
            this.NameTxt.CustomButton.Visible = false;
            this.NameTxt.Lines = new string[0];
            this.NameTxt.Location = new System.Drawing.Point(199, 66);
            this.NameTxt.MaxLength = 32767;
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.PasswordChar = '\0';
            this.NameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NameTxt.SelectedText = "";
            this.NameTxt.SelectionLength = 0;
            this.NameTxt.SelectionStart = 0;
            this.NameTxt.ShortcutsEnabled = true;
            this.NameTxt.Size = new System.Drawing.Size(107, 23);
            this.NameTxt.TabIndex = 7;
            this.NameTxt.UseSelectable = true;
            this.NameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // AddressLbl
            // 
            this.AddressLbl.AutoSize = true;
            this.AddressLbl.Location = new System.Drawing.Point(109, 188);
            this.AddressLbl.Name = "AddressLbl";
            this.AddressLbl.Size = new System.Drawing.Size(56, 19);
            this.AddressLbl.TabIndex = 5;
            this.AddressLbl.Text = "Address";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(60, 127);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(94, 19);
            this.Date.TabIndex = 3;
            this.Date.Text = "Submitting On";
            // 
            // OrderNamelbl
            // 
            this.OrderNamelbl.AutoSize = true;
            this.OrderNamelbl.Location = new System.Drawing.Point(84, 66);
            this.OrderNamelbl.Name = "OrderNamelbl";
            this.OrderNamelbl.Size = new System.Drawing.Size(81, 19);
            this.OrderNamelbl.TabIndex = 2;
            this.OrderNamelbl.Text = "OrderName";
            // 
            // OrderSubmit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 613);
            this.Controls.Add(this.OrderPanel);
            this.Name = "OrderSubmit";
            this.Text = "OrderSubmit";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OrderSubmit_FormClosing);
            this.OrderPanel.ResumeLayout(false);
            this.OrderPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel OrderPanel;
        private MetroFramework.Controls.MetroTextBox AddressTxt;
        private MetroFramework.Controls.MetroTextBox NameTxt;
        private MetroFramework.Controls.MetroLabel AddressLbl;
        private MetroFramework.Controls.MetroLabel Date;
        private MetroFramework.Controls.MetroLabel OrderNamelbl;
        private MetroFramework.Controls.MetroButton SubmitBtn;
        private MetroFramework.Controls.MetroDateTime SdateTxt;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}
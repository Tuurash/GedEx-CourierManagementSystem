﻿namespace CourierServiceManagement
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UsernameTxt = new MetroFramework.Controls.MetroTextBox();
            this.PasswordTxt = new MetroFramework.Controls.MetroTextBox();
            this.UserNameLbl1 = new MetroFramework.Controls.MetroLabel();
            this.Password = new MetroFramework.Controls.MetroLabel();
            this.Panel1 = new MetroFramework.Controls.MetroPanel();
            this.NewOrderBtn = new MetroFramework.Controls.MetroButton();
            this.NewUserBtn = new MetroFramework.Controls.MetroButton();
            this.LoginBtn = new MetroFramework.Controls.MetroButton();
            this.Panel2 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.DateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.DesignationTxt = new MetroFramework.Controls.MetroTextBox();
            this.SignUpBtn = new MetroFramework.Controls.MetroButton();
            this.UserNameLbl = new MetroFramework.Controls.MetroLabel();
            this.AddressLbl = new MetroFramework.Controls.MetroLabel();
            this.PhoneNumberLbl = new MetroFramework.Controls.MetroLabel();
            this.PasswordLbl = new MetroFramework.Controls.MetroLabel();
            this.PasswordTxt2 = new MetroFramework.Controls.MetroTextBox();
            this.NameTxt = new MetroFramework.Controls.MetroTextBox();
            this.AdressTxt = new MetroFramework.Controls.MetroTextBox();
            this.PhoneNumberTxt1 = new MetroFramework.Controls.MetroTextBox();
            this.Panel1.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // UsernameTxt
            // 
            // 
            // 
            // 
            this.UsernameTxt.CustomButton.Image = null;
            this.UsernameTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.UsernameTxt.CustomButton.Name = "";
            this.UsernameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.UsernameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.UsernameTxt.CustomButton.TabIndex = 1;
            this.UsernameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.UsernameTxt.CustomButton.UseSelectable = true;
            this.UsernameTxt.CustomButton.Visible = false;
            this.UsernameTxt.Lines = new string[0];
            this.UsernameTxt.Location = new System.Drawing.Point(153, 62);
            this.UsernameTxt.MaxLength = 32767;
            this.UsernameTxt.Name = "UsernameTxt";
            this.UsernameTxt.PasswordChar = '\0';
            this.UsernameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.UsernameTxt.SelectedText = "";
            this.UsernameTxt.SelectionLength = 0;
            this.UsernameTxt.SelectionStart = 0;
            this.UsernameTxt.ShortcutsEnabled = true;
            this.UsernameTxt.Size = new System.Drawing.Size(200, 23);
            this.UsernameTxt.TabIndex = 0;
            this.UsernameTxt.UseSelectable = true;
            this.UsernameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.UsernameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // PasswordTxt
            // 
            // 
            // 
            // 
            this.PasswordTxt.CustomButton.Image = null;
            this.PasswordTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PasswordTxt.CustomButton.Name = "";
            this.PasswordTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PasswordTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PasswordTxt.CustomButton.TabIndex = 1;
            this.PasswordTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PasswordTxt.CustomButton.UseSelectable = true;
            this.PasswordTxt.CustomButton.Visible = false;
            this.PasswordTxt.Lines = new string[0];
            this.PasswordTxt.Location = new System.Drawing.Point(153, 144);
            this.PasswordTxt.MaxLength = 32767;
            this.PasswordTxt.Name = "PasswordTxt";
            this.PasswordTxt.PasswordChar = '\0';
            this.PasswordTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PasswordTxt.SelectedText = "";
            this.PasswordTxt.SelectionLength = 0;
            this.PasswordTxt.SelectionStart = 0;
            this.PasswordTxt.ShortcutsEnabled = true;
            this.PasswordTxt.Size = new System.Drawing.Size(200, 23);
            this.PasswordTxt.TabIndex = 1;
            this.PasswordTxt.UseSelectable = true;
            this.PasswordTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PasswordTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // UserNameLbl1
            // 
            this.UserNameLbl1.AutoSize = true;
            this.UserNameLbl1.Location = new System.Drawing.Point(42, 62);
            this.UserNameLbl1.Name = "UserNameLbl1";
            this.UserNameLbl1.Size = new System.Drawing.Size(71, 19);
            this.UserNameLbl1.TabIndex = 2;
            this.UserNameLbl1.Text = "UserName";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(50, 148);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(64, 19);
            this.Password.TabIndex = 3;
            this.Password.Text = "Password";
            // 
            // Panel1
            // 
            this.Panel1.Controls.Add(this.NewOrderBtn);
            this.Panel1.Controls.Add(this.NewUserBtn);
            this.Panel1.Controls.Add(this.LoginBtn);
            this.Panel1.Controls.Add(this.UserNameLbl1);
            this.Panel1.Controls.Add(this.Password);
            this.Panel1.Controls.Add(this.PasswordTxt);
            this.Panel1.Controls.Add(this.UsernameTxt);
            this.Panel1.HorizontalScrollbarBarColor = true;
            this.Panel1.HorizontalScrollbarHighlightOnWheel = false;
            this.Panel1.HorizontalScrollbarSize = 10;
            this.Panel1.Location = new System.Drawing.Point(23, 63);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(377, 479);
            this.Panel1.TabIndex = 4;
            this.Panel1.VerticalScrollbarBarColor = true;
            this.Panel1.VerticalScrollbarHighlightOnWheel = false;
            this.Panel1.VerticalScrollbarSize = 10;
            // 
            // NewOrderBtn
            // 
            this.NewOrderBtn.Location = new System.Drawing.Point(153, 266);
            this.NewOrderBtn.Name = "NewOrderBtn";
            this.NewOrderBtn.Size = new System.Drawing.Size(173, 64);
            this.NewOrderBtn.TabIndex = 6;
            this.NewOrderBtn.Text = "New Order";
            this.NewOrderBtn.UseSelectable = true;
            this.NewOrderBtn.Click += new System.EventHandler(this.NewOrderBtn_Click);
            // 
            // NewUserBtn
            // 
            this.NewUserBtn.Location = new System.Drawing.Point(251, 432);
            this.NewUserBtn.Name = "NewUserBtn";
            this.NewUserBtn.Size = new System.Drawing.Size(75, 23);
            this.NewUserBtn.TabIndex = 5;
            this.NewUserBtn.Text = "New User";
            this.NewUserBtn.UseSelectable = true;
            this.NewUserBtn.Click += new System.EventHandler(this.NewUserBtn_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.Location = new System.Drawing.Point(153, 432);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.Size = new System.Drawing.Size(75, 23);
            this.LoginBtn.TabIndex = 4;
            this.LoginBtn.Text = "LOGIN";
            this.LoginBtn.UseSelectable = true;
            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.metroLabel1);
            this.Panel2.Controls.Add(this.DateTime1);
            this.Panel2.Controls.Add(this.DesignationTxt);
            this.Panel2.Controls.Add(this.SignUpBtn);
            this.Panel2.Controls.Add(this.UserNameLbl);
            this.Panel2.Controls.Add(this.AddressLbl);
            this.Panel2.Controls.Add(this.PhoneNumberLbl);
            this.Panel2.Controls.Add(this.PasswordLbl);
            this.Panel2.Controls.Add(this.PasswordTxt2);
            this.Panel2.Controls.Add(this.NameTxt);
            this.Panel2.Controls.Add(this.AdressTxt);
            this.Panel2.Controls.Add(this.PhoneNumberTxt1);
            this.Panel2.HorizontalScrollbarBarColor = true;
            this.Panel2.HorizontalScrollbarHighlightOnWheel = false;
            this.Panel2.HorizontalScrollbarSize = 10;
            this.Panel2.Location = new System.Drawing.Point(406, 63);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(450, 479);
            this.Panel2.TabIndex = 5;
            this.Panel2.VerticalScrollbarBarColor = true;
            this.Panel2.VerticalScrollbarHighlightOnWheel = false;
            this.Panel2.VerticalScrollbarSize = 10;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(110, 266);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(36, 19);
            this.metroLabel1.TabIndex = 15;
            this.metroLabel1.Text = "Date";
            // 
            // DateTime1
            // 
            this.DateTime1.CustomFormat = "yyyy-MM-dd";
            this.DateTime1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateTime1.Location = new System.Drawing.Point(198, 266);
            this.DateTime1.MinimumSize = new System.Drawing.Size(0, 29);
            this.DateTime1.Name = "DateTime1";
            this.DateTime1.Size = new System.Drawing.Size(200, 29);
            this.DateTime1.TabIndex = 14;
            this.DateTime1.ValueChanged += new System.EventHandler(this.metroDateTime1_ValueChanged);
            // 
            // DesignationTxt
            // 
            // 
            // 
            // 
            this.DesignationTxt.CustomButton.Image = null;
            this.DesignationTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.DesignationTxt.CustomButton.Name = "";
            this.DesignationTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.DesignationTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.DesignationTxt.CustomButton.TabIndex = 1;
            this.DesignationTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.DesignationTxt.CustomButton.UseSelectable = true;
            this.DesignationTxt.CustomButton.Visible = false;
            this.DesignationTxt.Lines = new string[] {
        "Customer"};
            this.DesignationTxt.Location = new System.Drawing.Point(198, 343);
            this.DesignationTxt.MaxLength = 32767;
            this.DesignationTxt.Name = "DesignationTxt";
            this.DesignationTxt.PasswordChar = '\0';
            this.DesignationTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.DesignationTxt.SelectedText = "";
            this.DesignationTxt.SelectionLength = 0;
            this.DesignationTxt.SelectionStart = 0;
            this.DesignationTxt.ShortcutsEnabled = true;
            this.DesignationTxt.Size = new System.Drawing.Size(200, 23);
            this.DesignationTxt.TabIndex = 11;
            this.DesignationTxt.Text = "Customer";
            this.DesignationTxt.UseSelectable = true;
            this.DesignationTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.DesignationTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // SignUpBtn
            // 
            this.SignUpBtn.Location = new System.Drawing.Point(141, 391);
            this.SignUpBtn.Name = "SignUpBtn";
            this.SignUpBtn.Size = new System.Drawing.Size(173, 64);
            this.SignUpBtn.TabIndex = 10;
            this.SignUpBtn.Text = "Sign Up!";
            this.SignUpBtn.UseSelectable = true;
            this.SignUpBtn.Click += new System.EventHandler(this.SignUpBtn_Click);
            // 
            // UserNameLbl
            // 
            this.UserNameLbl.AutoSize = true;
            this.UserNameLbl.Location = new System.Drawing.Point(61, 32);
            this.UserNameLbl.Name = "UserNameLbl";
            this.UserNameLbl.Size = new System.Drawing.Size(71, 19);
            this.UserNameLbl.TabIndex = 9;
            this.UserNameLbl.Text = "UserName";
            // 
            // AddressLbl
            // 
            this.AddressLbl.AutoSize = true;
            this.AddressLbl.Location = new System.Drawing.Point(61, 93);
            this.AddressLbl.Name = "AddressLbl";
            this.AddressLbl.Size = new System.Drawing.Size(56, 19);
            this.AddressLbl.TabIndex = 8;
            this.AddressLbl.Text = "Address";
            // 
            // PhoneNumberLbl
            // 
            this.PhoneNumberLbl.AutoSize = true;
            this.PhoneNumberLbl.Location = new System.Drawing.Point(61, 143);
            this.PhoneNumberLbl.Name = "PhoneNumberLbl";
            this.PhoneNumberLbl.Size = new System.Drawing.Size(99, 19);
            this.PhoneNumberLbl.TabIndex = 7;
            this.PhoneNumberLbl.Text = "Phone Number";
            // 
            // PasswordLbl
            // 
            this.PasswordLbl.AutoSize = true;
            this.PasswordLbl.Location = new System.Drawing.Point(61, 204);
            this.PasswordLbl.Name = "PasswordLbl";
            this.PasswordLbl.Size = new System.Drawing.Size(86, 19);
            this.PasswordLbl.TabIndex = 6;
            this.PasswordLbl.Text = "Set Password";
            // 
            // PasswordTxt2
            // 
            // 
            // 
            // 
            this.PasswordTxt2.CustomButton.Image = null;
            this.PasswordTxt2.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PasswordTxt2.CustomButton.Name = "";
            this.PasswordTxt2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PasswordTxt2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PasswordTxt2.CustomButton.TabIndex = 1;
            this.PasswordTxt2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PasswordTxt2.CustomButton.UseSelectable = true;
            this.PasswordTxt2.CustomButton.Visible = false;
            this.PasswordTxt2.Lines = new string[0];
            this.PasswordTxt2.Location = new System.Drawing.Point(198, 204);
            this.PasswordTxt2.MaxLength = 32767;
            this.PasswordTxt2.Name = "PasswordTxt2";
            this.PasswordTxt2.PasswordChar = '\0';
            this.PasswordTxt2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PasswordTxt2.SelectedText = "";
            this.PasswordTxt2.SelectionLength = 0;
            this.PasswordTxt2.SelectionStart = 0;
            this.PasswordTxt2.ShortcutsEnabled = true;
            this.PasswordTxt2.Size = new System.Drawing.Size(200, 23);
            this.PasswordTxt2.TabIndex = 5;
            this.PasswordTxt2.UseSelectable = true;
            this.PasswordTxt2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PasswordTxt2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NameTxt
            // 
            // 
            // 
            // 
            this.NameTxt.CustomButton.Image = null;
            this.NameTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.NameTxt.CustomButton.Name = "";
            this.NameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NameTxt.CustomButton.TabIndex = 1;
            this.NameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NameTxt.CustomButton.UseSelectable = true;
            this.NameTxt.CustomButton.Visible = false;
            this.NameTxt.Lines = new string[0];
            this.NameTxt.Location = new System.Drawing.Point(198, 32);
            this.NameTxt.MaxLength = 32767;
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.PasswordChar = '\0';
            this.NameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NameTxt.SelectedText = "";
            this.NameTxt.SelectionLength = 0;
            this.NameTxt.SelectionStart = 0;
            this.NameTxt.ShortcutsEnabled = true;
            this.NameTxt.Size = new System.Drawing.Size(200, 23);
            this.NameTxt.TabIndex = 4;
            this.NameTxt.UseSelectable = true;
            this.NameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // AdressTxt
            // 
            // 
            // 
            // 
            this.AdressTxt.CustomButton.Image = null;
            this.AdressTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.AdressTxt.CustomButton.Name = "";
            this.AdressTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AdressTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AdressTxt.CustomButton.TabIndex = 1;
            this.AdressTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AdressTxt.CustomButton.UseSelectable = true;
            this.AdressTxt.CustomButton.Visible = false;
            this.AdressTxt.Lines = new string[0];
            this.AdressTxt.Location = new System.Drawing.Point(198, 89);
            this.AdressTxt.MaxLength = 32767;
            this.AdressTxt.Name = "AdressTxt";
            this.AdressTxt.PasswordChar = '\0';
            this.AdressTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AdressTxt.SelectedText = "";
            this.AdressTxt.SelectionLength = 0;
            this.AdressTxt.SelectionStart = 0;
            this.AdressTxt.ShortcutsEnabled = true;
            this.AdressTxt.Size = new System.Drawing.Size(200, 23);
            this.AdressTxt.TabIndex = 3;
            this.AdressTxt.UseSelectable = true;
            this.AdressTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AdressTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // PhoneNumberTxt1
            // 
            // 
            // 
            // 
            this.PhoneNumberTxt1.CustomButton.Image = null;
            this.PhoneNumberTxt1.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PhoneNumberTxt1.CustomButton.Name = "";
            this.PhoneNumberTxt1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PhoneNumberTxt1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PhoneNumberTxt1.CustomButton.TabIndex = 1;
            this.PhoneNumberTxt1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PhoneNumberTxt1.CustomButton.UseSelectable = true;
            this.PhoneNumberTxt1.CustomButton.Visible = false;
            this.PhoneNumberTxt1.Lines = new string[0];
            this.PhoneNumberTxt1.Location = new System.Drawing.Point(198, 143);
            this.PhoneNumberTxt1.MaxLength = 32767;
            this.PhoneNumberTxt1.Name = "PhoneNumberTxt1";
            this.PhoneNumberTxt1.PasswordChar = '\0';
            this.PhoneNumberTxt1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PhoneNumberTxt1.SelectedText = "";
            this.PhoneNumberTxt1.SelectionLength = 0;
            this.PhoneNumberTxt1.SelectionStart = 0;
            this.PhoneNumberTxt1.ShortcutsEnabled = true;
            this.PhoneNumberTxt1.Size = new System.Drawing.Size(200, 23);
            this.PhoneNumberTxt1.TabIndex = 2;
            this.PhoneNumberTxt1.UseSelectable = true;
            this.PhoneNumberTxt1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PhoneNumberTxt1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 565);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel1);
            this.Name = "Login";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox UsernameTxt;
        private MetroFramework.Controls.MetroTextBox PasswordTxt;
        private MetroFramework.Controls.MetroLabel UserNameLbl1;
        private MetroFramework.Controls.MetroLabel Password;
        private MetroFramework.Controls.MetroPanel Panel1;
        private MetroFramework.Controls.MetroButton NewOrderBtn;
        private MetroFramework.Controls.MetroButton NewUserBtn;
        private MetroFramework.Controls.MetroButton LoginBtn;
        private MetroFramework.Controls.MetroPanel Panel2;
        private MetroFramework.Controls.MetroButton SignUpBtn;
        private MetroFramework.Controls.MetroLabel UserNameLbl;
        private MetroFramework.Controls.MetroLabel AddressLbl;
        private MetroFramework.Controls.MetroLabel PhoneNumberLbl;
        private MetroFramework.Controls.MetroLabel PasswordLbl;
        private MetroFramework.Controls.MetroTextBox PasswordTxt2;
        private MetroFramework.Controls.MetroTextBox NameTxt;
        private MetroFramework.Controls.MetroTextBox AdressTxt;
        private MetroFramework.Controls.MetroTextBox PhoneNumberTxt1;
        private MetroFramework.Controls.MetroTextBox DesignationTxt;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroDateTime DateTime1;
    }
}


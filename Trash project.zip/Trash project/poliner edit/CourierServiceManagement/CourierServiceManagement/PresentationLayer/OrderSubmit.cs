﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourierServiceManagement.PresentationLayer;
using CourierServiceManagement.DatabaseAccessLayer;
using CourierServiceManagement.BusinessLayer;

namespace CourierServiceManagement.PresentationLayer
{
    public partial class OrderSubmit :MetroFramework.Forms.MetroForm
    {
        private DataSet Ds { get; set; }
        private Login Log { get; set; }
        public OrderSubmit(Login log)
        {
            InitializeComponent();
        }

        private void OrderSubmit_Load(object sender, EventArgs e)
        {

        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                ProductRepository producttemp = new ProductRepository();
                producttemp.InsertProduct(this.NameTxt.Text, this.SdateTxt.Text, "submitted", this.AddressTxt.Text);

                MessageBox.Show("SuccessFul.");

                this.Close();
                Login log = new Login();
                log.Visible = true;

            }
            catch (Exception exc) { MessageBox.Show("Error :" + exc); }
        }

        private void OrderSubmit_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Visible = false;
            Log.Visible = true;
        }
    }
}

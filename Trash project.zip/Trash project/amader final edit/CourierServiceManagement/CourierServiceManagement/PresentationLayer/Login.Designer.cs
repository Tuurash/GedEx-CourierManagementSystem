﻿namespace CourierServiceManagement
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Panel1 = new MetroFramework.Controls.MetroPanel();
            this.NewUserBtn = new MetroFramework.Controls.MetroButton();
            this.LoginBtn = new MetroFramework.Controls.MetroButton();
            this.Panel2 = new MetroFramework.Controls.MetroPanel();
            this.SignUpBtn = new MetroFramework.Controls.MetroButton();
            this.UserNameIdLbl = new MetroFramework.Controls.MetroLabel();
            this.AddressLbl = new MetroFramework.Controls.MetroLabel();
            this.PhoneNumberLbl = new MetroFramework.Controls.MetroLabel();
            this.PasswordLbl = new MetroFramework.Controls.MetroLabel();
            this.PasswordTxt2 = new MetroFramework.Controls.MetroTextBox();
            this.NameTxt = new MetroFramework.Controls.MetroTextBox();
            this.AdressTxt = new MetroFramework.Controls.MetroTextBox();
            this.PhoneNumberTxt1 = new MetroFramework.Controls.MetroTextBox();
            this.UsernameTxt = new MetroFramework.Controls.MetroTextBox();
            this.PasswordTxt = new MetroFramework.Controls.MetroTextBox();
            this.Password = new MetroFramework.Controls.MetroLabel();
            this.LblUserName = new MetroFramework.Controls.MetroLabel();
            this.LoginPanel = new MetroFramework.Controls.MetroPanel();
            this.CustomBtn = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.LoginPanel0 = new MetroFramework.Controls.MetroPanel();
            this.Panel1.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.LoginPanel.SuspendLayout();
            this.LoginPanel0.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.Controls.Add(this.LoginPanel0);
            this.Panel1.Controls.Add(this.LoginPanel);
            this.Panel1.Controls.Add(this.NewUserBtn);
            this.Panel1.HorizontalScrollbarBarColor = true;
            this.Panel1.HorizontalScrollbarHighlightOnWheel = false;
            this.Panel1.HorizontalScrollbarSize = 10;
            this.Panel1.Location = new System.Drawing.Point(23, 63);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(377, 479);
            this.Panel1.TabIndex = 4;
            this.Panel1.VerticalScrollbarBarColor = true;
            this.Panel1.VerticalScrollbarHighlightOnWheel = false;
            this.Panel1.VerticalScrollbarSize = 10;
            // 
            // NewUserBtn
            // 
            this.NewUserBtn.Location = new System.Drawing.Point(143, 418);
            this.NewUserBtn.Name = "NewUserBtn";
            this.NewUserBtn.Size = new System.Drawing.Size(75, 23);
            this.NewUserBtn.TabIndex = 5;
            this.NewUserBtn.Text = "New User";
            this.NewUserBtn.UseSelectable = true;
            this.NewUserBtn.Click += new System.EventHandler(this.NewUserBtn_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.Location = new System.Drawing.Point(124, 200);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.Size = new System.Drawing.Size(75, 23);
            this.LoginBtn.TabIndex = 4;
            this.LoginBtn.Text = "LOGIN";
            this.LoginBtn.UseSelectable = true;
            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.SignUpBtn);
            this.Panel2.Controls.Add(this.UserNameIdLbl);
            this.Panel2.Controls.Add(this.AddressLbl);
            this.Panel2.Controls.Add(this.PhoneNumberLbl);
            this.Panel2.Controls.Add(this.PasswordLbl);
            this.Panel2.Controls.Add(this.PasswordTxt2);
            this.Panel2.Controls.Add(this.NameTxt);
            this.Panel2.Controls.Add(this.AdressTxt);
            this.Panel2.Controls.Add(this.PhoneNumberTxt1);
            this.Panel2.HorizontalScrollbarBarColor = true;
            this.Panel2.HorizontalScrollbarHighlightOnWheel = false;
            this.Panel2.HorizontalScrollbarSize = 10;
            this.Panel2.Location = new System.Drawing.Point(406, 63);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(450, 479);
            this.Panel2.TabIndex = 5;
            this.Panel2.VerticalScrollbarBarColor = true;
            this.Panel2.VerticalScrollbarHighlightOnWheel = false;
            this.Panel2.VerticalScrollbarSize = 10;
            // 
            // SignUpBtn
            // 
            this.SignUpBtn.Location = new System.Drawing.Point(150, 266);
            this.SignUpBtn.Name = "SignUpBtn";
            this.SignUpBtn.Size = new System.Drawing.Size(173, 64);
            this.SignUpBtn.TabIndex = 10;
            this.SignUpBtn.Text = "Sign Up!";
            this.SignUpBtn.UseSelectable = true;
            this.SignUpBtn.Click += new System.EventHandler(this.SignUpBtn_Click);
            // 
            // UserNameIdLbl
            // 
            this.UserNameIdLbl.AutoSize = true;
            this.UserNameIdLbl.Location = new System.Drawing.Point(85, 36);
            this.UserNameIdLbl.Name = "UserNameIdLbl";
            this.UserNameIdLbl.Size = new System.Drawing.Size(75, 19);
            this.UserNameIdLbl.TabIndex = 9;
            this.UserNameIdLbl.Text = "User Name";
            // 
            // AddressLbl
            // 
            this.AddressLbl.AutoSize = true;
            this.AddressLbl.Location = new System.Drawing.Point(104, 93);
            this.AddressLbl.Name = "AddressLbl";
            this.AddressLbl.Size = new System.Drawing.Size(56, 19);
            this.AddressLbl.TabIndex = 8;
            this.AddressLbl.Text = "Address";
            // 
            // PhoneNumberLbl
            // 
            this.PhoneNumberLbl.AutoSize = true;
            this.PhoneNumberLbl.Location = new System.Drawing.Point(61, 143);
            this.PhoneNumberLbl.Name = "PhoneNumberLbl";
            this.PhoneNumberLbl.Size = new System.Drawing.Size(99, 19);
            this.PhoneNumberLbl.TabIndex = 7;
            this.PhoneNumberLbl.Text = "Phone Number";
            // 
            // PasswordLbl
            // 
            this.PasswordLbl.AutoSize = true;
            this.PasswordLbl.Location = new System.Drawing.Point(75, 204);
            this.PasswordLbl.Name = "PasswordLbl";
            this.PasswordLbl.Size = new System.Drawing.Size(85, 19);
            this.PasswordLbl.TabIndex = 6;
            this.PasswordLbl.Text = "Set Password";
            // 
            // PasswordTxt2
            // 
            // 
            // 
            // 
            this.PasswordTxt2.CustomButton.Image = null;
            this.PasswordTxt2.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PasswordTxt2.CustomButton.Name = "";
            this.PasswordTxt2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PasswordTxt2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PasswordTxt2.CustomButton.TabIndex = 1;
            this.PasswordTxt2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PasswordTxt2.CustomButton.UseSelectable = true;
            this.PasswordTxt2.CustomButton.Visible = false;
            this.PasswordTxt2.Lines = new string[0];
            this.PasswordTxt2.Location = new System.Drawing.Point(198, 204);
            this.PasswordTxt2.MaxLength = 32767;
            this.PasswordTxt2.Name = "PasswordTxt2";
            this.PasswordTxt2.PasswordChar = '\0';
            this.PasswordTxt2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PasswordTxt2.SelectedText = "";
            this.PasswordTxt2.SelectionLength = 0;
            this.PasswordTxt2.SelectionStart = 0;
            this.PasswordTxt2.ShortcutsEnabled = true;
            this.PasswordTxt2.Size = new System.Drawing.Size(200, 23);
            this.PasswordTxt2.TabIndex = 5;
            this.PasswordTxt2.UseSelectable = true;
            this.PasswordTxt2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PasswordTxt2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // NameTxt
            // 
            // 
            // 
            // 
            this.NameTxt.CustomButton.Image = null;
            this.NameTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.NameTxt.CustomButton.Name = "";
            this.NameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.NameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.NameTxt.CustomButton.TabIndex = 1;
            this.NameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.NameTxt.CustomButton.UseSelectable = true;
            this.NameTxt.CustomButton.Visible = false;
            this.NameTxt.Lines = new string[0];
            this.NameTxt.Location = new System.Drawing.Point(198, 32);
            this.NameTxt.MaxLength = 32767;
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.PasswordChar = '\0';
            this.NameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.NameTxt.SelectedText = "";
            this.NameTxt.SelectionLength = 0;
            this.NameTxt.SelectionStart = 0;
            this.NameTxt.ShortcutsEnabled = true;
            this.NameTxt.Size = new System.Drawing.Size(200, 23);
            this.NameTxt.TabIndex = 4;
            this.NameTxt.UseSelectable = true;
            this.NameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.NameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // AdressTxt
            // 
            // 
            // 
            // 
            this.AdressTxt.CustomButton.Image = null;
            this.AdressTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.AdressTxt.CustomButton.Name = "";
            this.AdressTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.AdressTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.AdressTxt.CustomButton.TabIndex = 1;
            this.AdressTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.AdressTxt.CustomButton.UseSelectable = true;
            this.AdressTxt.CustomButton.Visible = false;
            this.AdressTxt.Lines = new string[0];
            this.AdressTxt.Location = new System.Drawing.Point(198, 89);
            this.AdressTxt.MaxLength = 32767;
            this.AdressTxt.Name = "AdressTxt";
            this.AdressTxt.PasswordChar = '\0';
            this.AdressTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.AdressTxt.SelectedText = "";
            this.AdressTxt.SelectionLength = 0;
            this.AdressTxt.SelectionStart = 0;
            this.AdressTxt.ShortcutsEnabled = true;
            this.AdressTxt.Size = new System.Drawing.Size(200, 23);
            this.AdressTxt.TabIndex = 3;
            this.AdressTxt.UseSelectable = true;
            this.AdressTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.AdressTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // PhoneNumberTxt1
            // 
            // 
            // 
            // 
            this.PhoneNumberTxt1.CustomButton.Image = null;
            this.PhoneNumberTxt1.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PhoneNumberTxt1.CustomButton.Name = "";
            this.PhoneNumberTxt1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PhoneNumberTxt1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PhoneNumberTxt1.CustomButton.TabIndex = 1;
            this.PhoneNumberTxt1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PhoneNumberTxt1.CustomButton.UseSelectable = true;
            this.PhoneNumberTxt1.CustomButton.Visible = false;
            this.PhoneNumberTxt1.Lines = new string[0];
            this.PhoneNumberTxt1.Location = new System.Drawing.Point(198, 143);
            this.PhoneNumberTxt1.MaxLength = 32767;
            this.PhoneNumberTxt1.Name = "PhoneNumberTxt1";
            this.PhoneNumberTxt1.PasswordChar = '\0';
            this.PhoneNumberTxt1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PhoneNumberTxt1.SelectedText = "";
            this.PhoneNumberTxt1.SelectionLength = 0;
            this.PhoneNumberTxt1.SelectionStart = 0;
            this.PhoneNumberTxt1.ShortcutsEnabled = true;
            this.PhoneNumberTxt1.Size = new System.Drawing.Size(200, 23);
            this.PhoneNumberTxt1.TabIndex = 2;
            this.PhoneNumberTxt1.UseSelectable = true;
            this.PhoneNumberTxt1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PhoneNumberTxt1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // UsernameTxt
            // 
            // 
            // 
            // 
            this.UsernameTxt.CustomButton.Image = null;
            this.UsernameTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.UsernameTxt.CustomButton.Name = "";
            this.UsernameTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.UsernameTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.UsernameTxt.CustomButton.TabIndex = 1;
            this.UsernameTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.UsernameTxt.CustomButton.UseSelectable = true;
            this.UsernameTxt.CustomButton.Visible = false;
            this.UsernameTxt.Lines = new string[0];
            this.UsernameTxt.Location = new System.Drawing.Point(121, 54);
            this.UsernameTxt.MaxLength = 32767;
            this.UsernameTxt.Name = "UsernameTxt";
            this.UsernameTxt.PasswordChar = '\0';
            this.UsernameTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.UsernameTxt.SelectedText = "";
            this.UsernameTxt.SelectionLength = 0;
            this.UsernameTxt.SelectionStart = 0;
            this.UsernameTxt.ShortcutsEnabled = true;
            this.UsernameTxt.Size = new System.Drawing.Size(200, 23);
            this.UsernameTxt.TabIndex = 0;
            this.UsernameTxt.UseSelectable = true;
            this.UsernameTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.UsernameTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // PasswordTxt
            // 
            // 
            // 
            // 
            this.PasswordTxt.CustomButton.Image = null;
            this.PasswordTxt.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.PasswordTxt.CustomButton.Name = "";
            this.PasswordTxt.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.PasswordTxt.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PasswordTxt.CustomButton.TabIndex = 1;
            this.PasswordTxt.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PasswordTxt.CustomButton.UseSelectable = true;
            this.PasswordTxt.CustomButton.Visible = false;
            this.PasswordTxt.Lines = new string[0];
            this.PasswordTxt.Location = new System.Drawing.Point(121, 136);
            this.PasswordTxt.MaxLength = 32767;
            this.PasswordTxt.Name = "PasswordTxt";
            this.PasswordTxt.PasswordChar = '\0';
            this.PasswordTxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PasswordTxt.SelectedText = "";
            this.PasswordTxt.SelectionLength = 0;
            this.PasswordTxt.SelectionStart = 0;
            this.PasswordTxt.ShortcutsEnabled = true;
            this.PasswordTxt.Size = new System.Drawing.Size(200, 23);
            this.PasswordTxt.TabIndex = 1;
            this.PasswordTxt.UseSelectable = true;
            this.PasswordTxt.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PasswordTxt.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(18, 140);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(63, 19);
            this.Password.TabIndex = 3;
            this.Password.Text = "Password";
            // 
            // LblUserName
            // 
            this.LblUserName.AutoSize = true;
            this.LblUserName.Location = new System.Drawing.Point(6, 54);
            this.LblUserName.Name = "LblUserName";
            this.LblUserName.Size = new System.Drawing.Size(75, 19);
            this.LblUserName.TabIndex = 2;
            this.LblUserName.Text = "User Name";
            // 
            // LoginPanel
            // 
            this.LoginPanel.Controls.Add(this.PasswordTxt);
            this.LoginPanel.Controls.Add(this.UsernameTxt);
            this.LoginPanel.Controls.Add(this.LblUserName);
            this.LoginPanel.Controls.Add(this.Password);
            this.LoginPanel.Controls.Add(this.LoginBtn);
            this.LoginPanel.HorizontalScrollbarBarColor = true;
            this.LoginPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.LoginPanel.HorizontalScrollbarSize = 10;
            this.LoginPanel.Location = new System.Drawing.Point(19, 19);
            this.LoginPanel.Name = "LoginPanel";
            this.LoginPanel.Size = new System.Drawing.Size(343, 246);
            this.LoginPanel.TabIndex = 6;
            this.LoginPanel.VerticalScrollbarBarColor = true;
            this.LoginPanel.VerticalScrollbarHighlightOnWheel = false;
            this.LoginPanel.VerticalScrollbarSize = 10;
            // 
            // CustomBtn
            // 
            this.CustomBtn.Location = new System.Drawing.Point(24, 35);
            this.CustomBtn.Name = "CustomBtn";
            this.CustomBtn.Size = new System.Drawing.Size(122, 23);
            this.CustomBtn.TabIndex = 7;
            this.CustomBtn.Text = "Customer Login";
            this.CustomBtn.UseSelectable = true;
            this.CustomBtn.Click += new System.EventHandler(this.CustomBtn_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(204, 35);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(123, 23);
            this.metroButton2.TabIndex = 8;
            this.metroButton2.Text = "Adminstration";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // LoginPanel0
            // 
            this.LoginPanel0.Controls.Add(this.metroButton2);
            this.LoginPanel0.Controls.Add(this.CustomBtn);
            this.LoginPanel0.HorizontalScrollbarBarColor = true;
            this.LoginPanel0.HorizontalScrollbarHighlightOnWheel = false;
            this.LoginPanel0.HorizontalScrollbarSize = 10;
            this.LoginPanel0.Location = new System.Drawing.Point(17, 282);
            this.LoginPanel0.Name = "LoginPanel0";
            this.LoginPanel0.Size = new System.Drawing.Size(345, 100);
            this.LoginPanel0.TabIndex = 6;
            this.LoginPanel0.VerticalScrollbarBarColor = true;
            this.LoginPanel0.VerticalScrollbarHighlightOnWheel = false;
            this.LoginPanel0.VerticalScrollbarSize = 10;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 570);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel1);
            this.Name = "Login";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.LoginPanel.ResumeLayout(false);
            this.LoginPanel.PerformLayout();
            this.LoginPanel0.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel Panel1;
        private MetroFramework.Controls.MetroButton NewUserBtn;
        private MetroFramework.Controls.MetroButton LoginBtn;
        private MetroFramework.Controls.MetroPanel Panel2;
        private MetroFramework.Controls.MetroButton SignUpBtn;
        private MetroFramework.Controls.MetroLabel UserNameIdLbl;
        private MetroFramework.Controls.MetroLabel AddressLbl;
        private MetroFramework.Controls.MetroLabel PhoneNumberLbl;
        private MetroFramework.Controls.MetroLabel PasswordLbl;
        private MetroFramework.Controls.MetroTextBox PasswordTxt2;
        private MetroFramework.Controls.MetroTextBox NameTxt;
        private MetroFramework.Controls.MetroTextBox AdressTxt;
        private MetroFramework.Controls.MetroTextBox PhoneNumberTxt1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton CustomBtn;
        private MetroFramework.Controls.MetroPanel LoginPanel;
        private MetroFramework.Controls.MetroTextBox PasswordTxt;
        private MetroFramework.Controls.MetroTextBox UsernameTxt;
        private MetroFramework.Controls.MetroLabel LblUserName;
        private MetroFramework.Controls.MetroLabel Password;
        private MetroFramework.Controls.MetroPanel LoginPanel0;
    }
}


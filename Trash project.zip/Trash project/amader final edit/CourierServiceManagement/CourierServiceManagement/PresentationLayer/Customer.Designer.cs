﻿namespace CourierServiceManagement.PresentationLayer
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvAll = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnSubmitted = new MetroFramework.Controls.MetroButton();
            this.LblWelcome = new MetroFramework.Controls.MetroLabel();
            this.LblName = new MetroFramework.Controls.MetroLabel();
            this.BtnDelivered = new MetroFramework.Controls.MetroButton();
            this.BtnNwOrder = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAll)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvAll
            // 
            this.dgvAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAll.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvAll.Location = new System.Drawing.Point(121, 107);
            this.dgvAll.Name = "dgvAll";
            this.dgvAll.Size = new System.Drawing.Size(516, 257);
            this.dgvAll.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Id";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "productName";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Condition";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Address";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "RecieverNumber";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.HeaderText = "SenderNumber";
            this.Column6.Name = "Column6";
            // 
            // BtnSubmitted
            // 
            this.BtnSubmitted.Location = new System.Drawing.Point(121, 420);
            this.BtnSubmitted.Name = "BtnSubmitted";
            this.BtnSubmitted.Size = new System.Drawing.Size(150, 49);
            this.BtnSubmitted.TabIndex = 1;
            this.BtnSubmitted.Text = "Submitted";
            this.BtnSubmitted.UseSelectable = true;
            this.BtnSubmitted.Click += new System.EventHandler(this.BtnSubmitted_Click);
            // 
            // LblWelcome
            // 
            this.LblWelcome.AutoSize = true;
            this.LblWelcome.Location = new System.Drawing.Point(121, 67);
            this.LblWelcome.Name = "LblWelcome";
            this.LblWelcome.Size = new System.Drawing.Size(68, 19);
            this.LblWelcome.TabIndex = 4;
            this.LblWelcome.Text = "Welcome ";
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Location = new System.Drawing.Point(196, 66);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(0, 0);
            this.LblName.TabIndex = 5;
            // 
            // BtnDelivered
            // 
            this.BtnDelivered.Location = new System.Drawing.Point(506, 416);
            this.BtnDelivered.Name = "BtnDelivered";
            this.BtnDelivered.Size = new System.Drawing.Size(131, 53);
            this.BtnDelivered.TabIndex = 7;
            this.BtnDelivered.Text = "Show Deliverd Percels";
            this.BtnDelivered.UseSelectable = true;
            this.BtnDelivered.Click += new System.EventHandler(this.BtnDelivered_Click);
            // 
            // BtnNwOrder
            // 
            this.BtnNwOrder.Location = new System.Drawing.Point(493, 42);
            this.BtnNwOrder.Name = "BtnNwOrder";
            this.BtnNwOrder.Size = new System.Drawing.Size(123, 44);
            this.BtnNwOrder.TabIndex = 8;
            this.BtnNwOrder.Text = "New Order";
            this.BtnNwOrder.UseSelectable = true;
            this.BtnNwOrder.Click += new System.EventHandler(this.BtnNwOrder_Click);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 533);
            this.Controls.Add(this.BtnNwOrder);
            this.Controls.Add(this.BtnDelivered);
            this.Controls.Add(this.LblName);
            this.Controls.Add(this.LblWelcome);
            this.Controls.Add(this.BtnSubmitted);
            this.Controls.Add(this.dgvAll);
            this.Name = "Customer";
            this.Text = "Customer";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAll)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAll;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private MetroFramework.Controls.MetroButton BtnSubmitted;
        private MetroFramework.Controls.MetroLabel LblWelcome;
        private MetroFramework.Controls.MetroLabel LblName;
        private MetroFramework.Controls.MetroButton BtnDelivered;
        private MetroFramework.Controls.MetroButton BtnNwOrder;
    }
}
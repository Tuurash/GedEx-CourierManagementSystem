﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourierServiceManagement.DatabaseAccessLayer;
using CourierServiceManagement.BusinessLayer;


namespace CourierServiceManagement.PresentationLayer
{
    public partial class NewEmployee : MetroFramework.Forms.MetroForm
    {
        private Connection con { get; set; }
        private DataSet Ds { get; set; }
        private Manager Man { get; set; }
        public NewEmployee(Manager man)
        {
            InitializeComponent();
            this.con = new Connection();
            this.Man = man;
        }

        private void btnHire_Click(object sender, EventArgs e)
        {

            var emprepo = new EmployeeRepository();
            emprepo.Insert(this.txtName.Text, this.txtPhone.Text, this.dtJoin.Text, this.txtPassword.Text, this.txtAddress.Text);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Man.Visible = true;
        }

        private void NewEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Visible = false;
            Man.Visible = true;
        }
    }
}
